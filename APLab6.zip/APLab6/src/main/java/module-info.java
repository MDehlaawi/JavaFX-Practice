module com.mycompany.aplab6 {
    requires javafx.controls;
    exports com.mycompany.aplab6;
}
